<?php
include 'db.php';
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $grades = $_POST['grades'];

    foreach ($grades as $subject => $grade) {
        $stmt = $conn->prepare("INSERT INTO grades (user_id, subject, grade) VALUES (?, ?, ?)");
        $stmt->bind_param("isd", $user_id, $subject, $grade);
        $stmt->execute();
    }

    echo "Grades submitted successfully! <a href='dashboard.php'>Go back</a>";
}
?>

<form method="POST">
    <label>SCITECH:</label>
    <input type="number" name="grades[SCITECH]" step="0.01" required>
    <label>ORGMAN:</label>
    <input type="number" name="grades[ORGMAN]" step="0.01" required>
    <label>DEVTECH:</label>
    <input type="number" name="grades[DEVTECH]" step="0.01" required>
    <label>ORTPROG:</label>
    <input type="number" name="grades[ORTPROG]" step="0.01" required>
    <label>PURPCOM:</label>
    <input type="number" name="grades[PURPCOM]" step="0.01" required>
    <label>PATHFIT:</label>
    <input type="number" name="grades[PATHFIT]" step="0.01" required>
    <label>DBMS:</label>
    <input type="number" name="grades[DBMS]" step="0.01" required>
    <label>DASTRAL:</label>
    <input type="number" name="grades[DASTRAL]" step="0.01" required>
    <button type="submit">Submit Grades</button>
</form>
