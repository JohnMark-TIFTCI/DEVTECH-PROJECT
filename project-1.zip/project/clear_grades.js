function clearGrades() {
    var subjects = ['SCITECH', 'ORGMAN', 'DEVTECH', 'ORTPROG', 'PURPCOM', 'PATHFIT', 'DBMS', 'DASTRAL'];
    subjects.forEach(function(subject) {
        document.getElementById(subject + '_prelim').value = '';
        document.getElementById(subject + '_midterm').value = '';
        document.getElementById(subject + '_finals').value = '';
        document.getElementById(subject + '_average').innerText = '';
    });
    // Reset the overall average
    document.getElementById('overall_average').innerText = '0.00';
}