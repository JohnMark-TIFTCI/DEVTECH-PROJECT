<?php
session_start();
include 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$username = $_SESSION['username'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $grades = $_POST['grades'];

    // Initialize variables
    $total_average = 0;
    $total_subjects = count($grades);

    // Create a new form entry
    $stmt = $conn->prepare("INSERT INTO forms (username) VALUES (?)");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $form_id = $stmt->insert_id;

    // Insert grades for each subject
    foreach ($grades as $subject => $scores) {
        $average = array_sum($scores) / count($scores);
        $total_average += $average;

        $stmt = $conn->prepare("INSERT INTO grades (form_id, username, subject, prelim, midterm, finals, average) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issdddd", $form_id, $username, $subject, $scores['prelim'], $scores['midterm'], $scores['finals'], $average);
        $stmt->execute();
    }

    // Calculate final average
    $final_average = $total_average / $total_subjects;

    // Redirect to grading form with confirmation
    header("Location: grading_form.php?final_average=" . urlencode($final_average));
    exit();
}

// Fetch previously submitted grades (latest form only)
$latest_form = $conn->query("SELECT id FROM forms WHERE username='$username' ORDER BY created_at DESC LIMIT 1");
$grades_data = [];
if ($latest_form->num_rows > 0) {
    $latest_form_id = $latest_form->fetch_assoc()['id'];
    $result = $conn->query("SELECT * FROM grades WHERE form_id='$latest_form_id'");
    while ($row = $result->fetch_assoc()) {
        $grades_data[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <title>Grading Form</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="validation.js"></script>
    <script src="live_calculation.js"></script>
    <script src="clear_grades.js"></script>
</head>
<body>
    <h1>Grading Form</h1>

    <!-- Display Final Average After Submission -->
    <?php if (isset($_GET['final_average'])): ?>
        <p><strong>Your Final Average:</strong> <?php echo number_format($_GET['final_average'], 2); ?></p>
    <?php endif; ?>

    <!-- Form to Enter Grades -->
    <form method="POST" id="grading_form" onsubmit="submitGrades(event)">
        <table border="1" cellpadding="10">
            <tr>
                <th>Subject</th>
                <th>Prelim</th>
                <th>Midterm</th>
                <th>Finals</th>
                <th>Average</th>
            </tr>
            <?php
            $subjects = ['SCITECH', 'ORGMAN', 'DEVTECH', 'ORTPROG', 'PURPCOM', 'PATHFIT', 'DBMS', 'DASTRAL'];
            foreach ($subjects as $subject):
                $prelim = $midterm = $finals = $average = '';
                foreach ($grades_data as $data) {
                    if ($data['subject'] == $subject) {
                        $prelim = $data['prelim'];
                        $midterm = $data['midterm'];
                        $finals = $data['finals'];
                        $average = $data['average'];
                        break;
                    }
                }
            ?>
            <tr>
                <td><?php echo $subject; ?></td>
                <td><input type="number" id="<?php echo $subject; ?>_prelim" name="grades[<?php echo $subject; ?>][prelim]" value="<?php echo $prelim; ?>" min="0" max="100" required oninput="calculateAverage('<?php echo $subject; ?>')"></td>
                <td><input type="number" id="<?php echo $subject; ?>_midterm" name="grades[<?php echo $subject; ?>][midterm]" value="<?php echo $midterm; ?>" min="0" max="100" required oninput="calculateAverage('<?php echo $subject; ?>')"></td>
                <td><input type="number" id="<?php echo $subject; ?>_finals" name="grades[<?php echo $subject; ?>][finals]" value="<?php echo $finals; ?>" min="0" max="100" required oninput="calculateAverage('<?php echo $subject; ?>')"></td>
                <td><span id="<?php echo $subject; ?>_average"><?php echo $average ? number_format($average, 2) : ''; ?></span></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <br>
        <button type="submit">Submit Grades</button><br>
        <button type="button" onclick="clearGrades()">Clear Grades</button>
    </form>

    <p><strong>Overall Average:</strong> <span id="overall_average">0.00</span></p>

    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
