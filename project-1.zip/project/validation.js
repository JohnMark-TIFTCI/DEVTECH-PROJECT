document.querySelector("form").addEventListener("submit", function (event) {
    const gradeInputs = document.querySelectorAll("input[type='number']");
    let isValid = true;

    gradeInputs.forEach(input => {
        const value = parseFloat(input.value);
        if (isNaN(value) || value < 0 || value > 100) {
            isValid = false;
            input.style.border = "2px solid red"; // Highlight invalid input
        } else {
            input.style.border = ""; // Reset valid input styling
        }
    });

    if (!isValid) {
        alert("Please ensure all grades are between 0 and 100.");
        event.preventDefault(); // Stop form submission
    }
});
