<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <title>Dashboard</title>
</head>
<body>
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
    <br><br>
    <a href="grading_form.php">Go to Grading Form</a><br>
    <a href="history.php">View Grading History</a><br>
    <a href="logout.php">Logout</a>
</body>
</html>
