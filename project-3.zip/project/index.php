<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TIFTCI Grading System</title>
    <link rel="stylesheet" href="design.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Welcome to the TIFTCI Grading System</h1>
        </header>

        <section class="intro">
            <p>The TIFTCI Grading System is designed to simplify and streamline the grading process for students and instructors alike. You can enter your grades, view your history, and calculate your final average easily.</p>
        </section>

        <section class="auth-buttons">
            <!-- Login and Register Buttons -->
            <div class="button-container">
                <a href="login.php" class="btn">Login</a>
                <a href="register.php" class="btn">Register</a>
            </div>
        </section>

        <footer>
            <p>&copy; 2024 TIFTCI Grading System. All rights reserved.</p>
        </footer>
    </div>
</body>
</html>
<!-- 
-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS grading_system;

-- Use the grading_system database
USE grading_system;

-- 1. Users Table (for storing user login information)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255),
    email VARCHAR(255)
);

-- 2. Forms Table (to store each form entry for users)
CREATE TABLE forms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    section VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (username) REFERENCES users(username)
);

-- 3. Grades Table (to store grades for each subject)
CREATE TABLE grades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    form_id INT NOT NULL,
    username VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    prelim DECIMAL(5,2) DEFAULT 0,
    midterm DECIMAL(5,2) DEFAULT 0,
    finals DECIMAL(5,2) DEFAULT 0,
    average DECIMAL(5,2) DEFAULT 0,
    FOREIGN KEY (form_id) REFERENCES forms(id),
    FOREIGN KEY (username) REFERENCES users(username)
);

-- 4. Sessions Table (to store session data if you want persistent sessions in database)
CREATE TABLE sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(255) UNIQUE NOT NULL,
    session_data TEXT NOT NULL,
    user_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);


-->