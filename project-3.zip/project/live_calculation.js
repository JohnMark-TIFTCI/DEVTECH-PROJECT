function calculateAverage(subject) {
    var prelim = parseFloat(document.getElementById(subject + '_prelim').value) || 0;
    var midterm = parseFloat(document.getElementById(subject + '_midterm').value) || 0;
    var finals = parseFloat(document.getElementById(subject + '_finals').value) || 0;
    var average = (prelim + midterm + finals) / 3;

    document.getElementById(subject + '_average').innerText = average.toFixed(2);
    updateOverallAverage();
}

function updateOverallAverage() {
    var totalAverage = 0;
    var subjects = ['SCITECH', 'ORGMAN', 'DEVTECH', 'ORTPROG', 'PURPCOM', 'PATHFIT', 'DBMS', 'DASTRAL'];
    var totalSubjects = 0;
    subjects.forEach(function(subject) {
        var average = parseFloat(document.getElementById(subject + '_average').innerText) || 0;
        totalAverage += average;
        totalSubjects++;
    });
    var finalAverage = totalAverage / totalSubjects;
    document.getElementById('overall_average').innerText = finalAverage.toFixed(2);
}

function submitGrades(event) {
    event.preventDefault();

    var formData = $('#grading_form').serialize(); // Collect form data

    $.ajax({
        type: 'POST',
        url: 'grading_form.php',
        data: formData,
        success: function(response) {
            // Handle response (e.g., show confirmation or update UI)
            alert("Grades successfully submitted!");
            window.location.reload(); // Reload the page to update the form
        },
        error: function() {
            alert("Error submitting grades.");
        }
    });
}