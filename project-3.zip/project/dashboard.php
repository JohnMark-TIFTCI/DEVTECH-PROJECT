<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="design.css">
</head>
<body>

    <div class="container">
        <header>
            <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        </header>

        <div class="button-box">
            <a href="grading_form.php" class="btn">Grading Form</a>
            <a href="history.php" class="btn">History</a>
            <a href="logout.php" class="btn">Logout</a>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 TIFTCI Grading System. All rights reserved.</p>
    </footer>

</body>
</html>
