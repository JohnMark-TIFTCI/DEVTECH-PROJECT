<?php
session_start();
include 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$username = $_SESSION['username'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $grades = $_POST['grades'];
    $name = $_POST['name'];
    $section = $_POST['section'];

    // Initialize variables
    $total_average = 0;
    $total_subjects = count($grades);

    // Create a new form entry
    $stmt = $conn->prepare("INSERT INTO forms (username, name, section) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $name, $section);
    $stmt->execute();
    $form_id = $stmt->insert_id;

    // Insert grades for each subject
    foreach ($grades as $subject_key => $scores) {
        $subject_name = $scores['subject'];  // Get the actual subject name entered by the user
        $average = array_sum($scores) / count($scores);
        $total_average += $average;

        $stmt = $conn->prepare("INSERT INTO grades (form_id, username, subject, prelim, midterm, finals, average) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issdddd", $form_id, $username, $subject_name, $scores['prelim'], $scores['midterm'], $scores['finals'], $average);
        $stmt->execute();
    }

    // Calculate final average
    $final_average = $total_average / $total_subjects;

    // Redirect to grading form with confirmation
    header("Location: grading_form.php?final_average=" . urlencode($final_average));
    exit();
}

// Fetch previously submitted grades (latest form only)
$grades_data = []; // Initialize as an empty array
$latest_form = $conn->query("SELECT id FROM forms WHERE username='$username' ORDER BY created_at DESC LIMIT 1");
if ($latest_form->num_rows > 0) {
    $latest_form_id = $latest_form->fetch_assoc()['id'];
    $result = $conn->query("SELECT * FROM grades WHERE form_id='$latest_form_id'");
    while ($row = $result->fetch_assoc()) {
        $grades_data[] = $row; // Populate $grades_data
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="design.css">
    <title>Grading Form</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="validation.js"></script>
    <script src="live_calculation.js"></script>
    <script src="clear_grades.js"></script>
    <script src="subject.js"></script>
</head>
<body>
<div class="button-box">
            <a href="dashboard.php" class="btn">Dashboard</a>
            <a href="history.php" class="btn">History</a>
            <a href="logout.php" class="btn">Logout</a>
        </div>
    <h1>Grading Form</h1>

    <!-- Display Final Average After Submission -->
    <?php if (isset($_GET['final_average'])): ?>
        <p><strong>Your Final Average:</strong> <?php echo number_format($_GET['final_average'], 2); ?></p>
    <?php endif; ?>

    <!-- Form to Enter Grades -->
    <form method="POST" id="grading_form" onsubmit="submitGrades(event)">
        <!-- Name and Section Inputs -->
        <div style="display: flex; gap: 20px; margin-bottom: 20px;">
            <input type="text" name="name" placeholder="Enter your name" required style="flex: 1;">
            <input type="text" name="section" placeholder="Enter your section" required style="flex: 1;">
        </div>

        <!-- Table for Grading -->
        <table id="grading_table" border="1" cellpadding="10">
            <thead>
                <tr>
                    <th>Subject</th>
                    <th>Prelim</th>
                    <th>Midterm</th>
                    <th>Finals</th>
                    <th>Average</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- Initially, only one subject is present -->
                <tr id="subject_row_1">
                    <td><input type="text" name="grades[subject_1][subject]" placeholder="Enter Subject" required oninput="adjustInputLength(1); calculateAverage(1)"></td>
                    <td><input type="number" name="grades[subject_1][prelim]" min="0" max="100" required oninput="calculateAverage(1)"></td>
                    <td><input type="number" name="grades[subject_1][midterm]" min="0" max="100" required oninput="calculateAverage(1)"></td>
                    <td><input type="number" name="grades[subject_1][finals]" min="0" max="100" required oninput="calculateAverage(1)"></td>
                    <td><span id="subject_1_average"></span></td>
                    <td><button type="button" onclick="removeSubject(1)">Remove</button></td>
                </tr>
            </tbody>
        </table>
        <br>
        <button type="submit">Submit Grades</button><br>
        <button type="button" onclick="clearGrades()">Clear Grades</button>
        <button type="button" onclick="addSubject()">Add Subject</button>
    </form>

    <p><strong>Overall Average:</strong> <span id="overall_average">0.00</span></p>

    
</body>
</html>
