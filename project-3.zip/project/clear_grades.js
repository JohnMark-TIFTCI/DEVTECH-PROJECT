function clearGrades() {
    // Clear grades for both predefined and dynamically added subjects
    let subjectRows = document.querySelectorAll('[id^="subject_row_"]'); // Select all subject rows
    subjectRows.forEach(function(row) {
        const subjectId = row.id.split('_')[2]; // Extract the subject id (1, 2, etc.)

        // Clear the values in the respective input fields for both predefined and dynamically added subjects
        const subjectInput = document.querySelector(`[name="grades[subject_${subjectId}][subject]"]`);
        const prelimInput = document.querySelector(`[name="grades[subject_${subjectId}][prelim]"]`);
        const midtermInput = document.querySelector(`[name="grades[subject_${subjectId}][midterm]"]`);
        const finalsInput = document.querySelector(`[name="grades[subject_${subjectId}][finals]"]`);

        if (subjectInput) subjectInput.value = '';  // Subject name
        if (prelimInput) prelimInput.value = '';  // Prelim grade
        if (midtermInput) midtermInput.value = '';  // Midterm grade
        if (finalsInput) finalsInput.value = '';  // Finals grade
        document.querySelector(`#subject_${subjectId}_average`).innerText = ''; // Clear average
    });

    // Reset the overall average
    document.getElementById('overall_average').innerText = '0.00';
}
