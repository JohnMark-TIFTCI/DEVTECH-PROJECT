<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TIFTCI Grading System</title>
    <link rel="stylesheet" href="design.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Welcome to the TIFTCI Grading System</h1>
        </header>

        <section class="intro">
            <p>The TIFTCI Grading System is designed to simplify and streamline the grading process for students and instructors alike. You can enter your grades, view your history, and calculate your final average easily.</p>
        </section>

        <section class="auth-buttons">
            <!-- Login and Register Buttons -->
            <div class="button-container">
                <a href="login.php" class="btn">Login</a>
                <a href="register.php" class="btn">Register</a>
            </div>
        </section>

        <footer>
            <p>&copy; 2024 TIFTCI Grading System. All rights reserved.</p>
        </footer>
    </div>
</body>
</html>
