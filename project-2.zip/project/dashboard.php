<?php
// Start the session at the beginning
session_start();

// Check if the 'username' session variable is set
if (!isset($_SESSION['username'])) {
    // Redirect to login page if the session is not set
    header("Location: index.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="design.css">
    <title>Dashboard</title>
    <style>
        /* Corrected CSS for background image */
        body {
            background-image: url('pictures/OIP.jpg'); 
            background-size: cover; /* Make sure the image covers the entire body */
            background-position: center center; /* Center the image */
            background-attachment: fixed; /* Keeps the image fixed while scrolling */
        }
    </style>
</head>
<body>
    <div class="button-box">
        <a href="grading_form.php" class="btn">Go to Grading Form</a>
        <a href="history.php" class="btn">View Grading History</a>
        <a href="logout.php" class="btn">Logout</a>
    </div>
    
    <div class="container">
        <!-- Display the username if the session variable is set -->
        <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
    </div>
</body>
</html>
